"""
procli - A CLI tool for creating and managing Python projects using Pipenv.
"""

__version__ = "0.0.1"

# Optionally, you can expose the CLI function so that users can import it if needed.
from .cli import cli